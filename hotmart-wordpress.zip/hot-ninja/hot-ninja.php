<?php
/**
 * Plugin Name: Escola Ninja WP Integração Hotmart
 * Plugin URI: https://www.escolaninjawp.com.br/
 * Description: Plugin d'e Integração do Hotmart com WordPress
 * Version: 2
 * Author: Flavio Henrique - Escola Ninja WP
 * Author URI: https://escolaninjawp.com.br/
 **/

define('CD_PLUGIN_PATH', plugin_dir_path(__FILE__));
require_once CD_PLUGIN_PATH . 'redux/redux.php';

ini_set('display_errors','Off');
ini_set('error_reporting', E_ALL );

function ninja_wp_html_mail()
{
    return "text/html";
}
add_filter('wp_mail_content_type', 'ninja_wp_html_mail');

add_action('rest_api_init', function () {
    register_rest_route('hot/ninja', '/wp/', array(
        'methods' => 'POST',
        'callback' => 'hot_ninja_wp',
    ));
});


add_action( 'admin_notices', 'enwp_redux_framework_check' );

function enwp_redux_framework_check() {
    if ( ! class_exists('Redux_Framework_Plugin',false) ) {
        echo '<div class="error"><p><strong>ATENÇÃO ATENÇÃO</strong>Você precisa Instalar o Gutenberg Template Library & Redux Framework para usar este Plugin <a href="/wp-admin/plugin-install.php?s=redux%20framework&tab=search&type=term">Clique aqui para Instalar</a></p></div>';
    }
}



function hot_ninja_wp($data)
{
    global $ninja_redux;
    $token = $ninja_redux['token_hot'];
    //Get all headers send by Hotmart
    $headers = getallheaders();
    $token_hotmart = $headers['X-Hotmart-Hottok'];

    // Vamos validar se a Requição e o token é valida

        $request_body = file_get_contents('php://input');
        $data = json_decode($request_body, true);

        $evento = $data['event'];
        $email_comprador = $data['data']['buyer'];
        $nome_produto = $data['data']['product']['name'];

        $produto_lower = strtolower($nome_produto);
        $titulo_produto_sem_espaco_hotmart = str_replace(' ', '', $produto_lower);


        $args = array(
            'post_type'      => 'product',
            'posts_per_page' => -1,
        );


        $produtos = get_posts($args);
 
        $dados = array();
        // Vamos se há um produto com o mesmo titulo do produto no Hotmart
        foreach ($produtos as $key => $value) {
            $titulo_produto = $value->post_title;
            $produto_lower_each = strtolower($titulo_produto);
            $titulo_produto_sem_espaco_each = str_replace(' ', '', $produto_lower_each);
            
         
            if($titulo_produto_sem_espaco_hotmart == $titulo_produto_sem_espaco_each){
                $dados['status'] = 'true';
                $dados['id_produto'] = $value->ID;
            }
        }
        
        
        $id_curso_relacionado_produto_woo_ld = get_post_meta($dados['id_produto'], '_related_course',true);

     



        $senha = wp_generate_password(6, false);
        $user = get_user_by('email', $email_comprador['email']);
        $user_id = $user->ID;
        if ($evento == "PURCHASE_APPROVED") {

            // Vai entrar aqui se a compra tiver aprovada

            if (email_exists($email_comprador['email'])) {
                // Se Tiver algum usuário já registrado no WordPress nós só atualizaremos os dados dele.

                // Caso você precise fazer integração com algum plugin do WordPress você pode adicionar o Código personalizado aqui

                //Integração com O Learndash
                //ld_update_course_access( $user_id, $id_curso_relacionado_produto_woo_ld[0], false );
    

                integracao_woocommerce_hotmart_ninja_wp($email_comprador['email'],$dados);
                send_email_user($email_comprador['email'], $senha);


                //write_log("Teste");

            } else {

                // Se não tiver usuário criado no WordPress ele vai criar aqui.

                $userdata = array(
                    'user_login' => $email_comprador['email'],
                    'user_email' => $email_comprador['email'],
                    'first_name' => '',
                    'last_name' => '',
                    'user_pass' => $senha,
                    'role' => 'subscriber',
                );
                $user_id = wp_insert_user($userdata);

                // Caso você precise fazer integração com algum plugin do WordPress você pode adicionar o Código personalizado aqui

                // Integração com Learndash
                ld_update_course_access( $user_id, $id_curso_relacionado_produto_woo_ld[0], false );
                
                send_email_user($email_comprador['email'], $senha);
                integracao_woocommerce_hotmart_ninja_wp($email_comprador['email'],$dados);
                

            }
        } elseif ($evento == "PURCHASE_CANCELED" or $evento == "PURCHASE_REFUNDED" or $evento == "PURCHASE_CHARGEBACK") {
            /* Aqui vocÊ vai colocar o código para excluir o usuário caso seja seu interesse ou até atualizar alguma informação do usuário caso ele
        Tenha pedido extorno, cancelado a compra ou etc.

        A regra de negócio do meu cliente não tem a necessidade de excluir o usuário e sim tirar o acesso dele ao curso de learndash


         */
         
                //ld_update_course_access( $user_id, $id_curso_relacionado_produto_woo_ld[0], true );

        }
    
}

// Função para salvar log para debugar
if (!function_exists('write_log')) {

    function write_log($log)
    {
        if (true === WP_DEBUG) {
            if (is_array($log) || is_object($log)) {
                error_log(print_r($log, true));
            } else {
                error_log($log);
            }
        }
    }

}

function send_email_user($email, $senha)
{

    global $ninja_redux;

    $habilitar_email = $ninja_redux['habilitar_email'];

    if ($habilitar_email == true) {
        $subject = $ninja_redux['titulo_email'];
        $corpo = $ninja_redux['desc_email'];

        $search  = array('{{email}}', '{{senha}}');
        $replace = array($email, $senha);


        $mensagem = str_replace($search,$replace, $corpo);

        $to = $email;
        $subject = $subject;
        $body = $mensagem;
        $headers = array('Content-Type: text/html; charset=UTF-8');

        //Envia um email para o comprador
        wp_mail($to, $subject, $body, $headers);

    }
}

function integracao_woocommerce_hotmart_ninja_wp($email,$dados)
{
    global $woocommerce;
    global $ninja_redux;

    $id_produto = $ninja_redux['id_produto_woo'];
    $habilita_woo = $ninja_redux['habilitar_woo_integracao'];
    if ($habilita_woo == 1) {
        
        if(in_array('true',$dados)){
        

        // ID do produto do Learndash
        //$id_curso_relacionado_produto_woo_ld = get_post_meta($dados['id_produto'], '_related_course',true);
        

      
        $address = array(
            'first_name' => '',
            'last_name' => '',
            'company' => '',
            'email' => $email,
            'phone' => '',
            'address_1' => '',
            'address_2' => '',
            'city' => '',
            'state' => '',
            'postcode' => '',
            'country' => '',
        );


        $user = get_user_by('email',$email);

        $user_id = $user->ID;
        // Now we create the order
        $order = wc_create_order();

        // The add_product() function below is located in /plugins/woocommerce/includes/abstracts/abstract_wc_order.php
        $order->add_product(get_product($dados['id_produto']), 1); // This is an existing SIMPLE product
        $order->set_address($address, 'billing');
        //
        $order->calculate_totals();
        $order->update_status("wc-completed", 'Order Integração Escola Ninja WP Hotmart', true);


        //Atualiza o usuario com o pedido
        update_post_meta($order->get_order_number(), '_customer_user',$user_id);
        
        //ld_update_course_access( $user_id,$id_curso_relacionado_produto_woo_ld, false );



 }else{


        }
        
        
        
    }
}
add_action('woocommerce_order_status_changed', 'integracao_woocommerce_hotmart_ninja_wp', 10, 4);
