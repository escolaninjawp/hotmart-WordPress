<?php

if (!class_exists('Redux')) {
    return;
}

$opt_name = 'ninja_redux';

$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]" . '/wp-json/hot/ninja/wp';


$theme = wp_get_theme(); // For use with some settings. Not necessary.

$args = array(
    'display_name' => $theme->get('Name'),
    'display_version' => $theme->get('Version'),
    'menu_title' => esc_html__('Hotmart Conect Ninja WP', 'ninja_hot_conect'),
    'customizer' => true,
);

Redux::setArgs($opt_name, $args);

Redux::setSection($opt_name,

    array(
        'title' => esc_html__('Configuracoes', 'ninja_hot_conect'),
        'id' => 'configuracoes',
        'desc' => esc_html__('Configurações Gerais do Plugin', 'ninja_hot_conect'),
        'icon' => 'el el-home',
        'fields' => array(
            array(
                'id' => 'url_endpoin',
                'readonly' => true,
                'type' => 'info',
                'notice' => true,
                'title' => esc_html__('Endpoint para inserir no Hotmart', 'ninja_hot_conect'),
                'desc' => esc_html__($actual_link, 'ninja_hot_conect'),

            ),

            array(
                'id' => 'token_hot',
                'type' => 'text',
                'title' => esc_html__('Hottok de verificação', 'ninja_hot_conect'),
                'desc' => esc_html__('Acesse a URL https://app-vlc.hotmart.com/tools/webhook para Pegar o seu token', 'ninja_hot_conect'),

            ),

        ),
    ),

);

Redux::setSection($opt_name,

    array(
        'title' => esc_html__('E-mails', 'ninja_hot_conect'),
        'id' => 'emails',
        'desc' => esc_html__('Configurações de e-mails que será enviado', 'ninja_hot_conect'),
        'icon' => 'el el-home',
        'fields' => array(
            array(
                'id' => 'habilitar_email',
                'type' => 'checkbox',
                'title' => esc_html__('Habilitar envio de email', 'ninja_hot_conect'),
                'desc' => esc_html__('Habilite essa opção para usar a configuração de e-mail abaixo', 'ninja_hot_conect'),

            ),
            array(
                'id' => 'titulo_email',
                'type' => 'text',
                'title' => esc_html__('Título do E-mail (Subject)', 'ninja_hot_conect'),
                'desc' => esc_html__('Título do e-mails que irá chegar para o seu cliente / Aluno', 'ninja_hot_conect'),

            ),
            array(

                'id' => 'desc_email',
                'type' => 'editor',
                'title' => __('Corpo do Email', 'redux_docs_generator'),
                'desc' => __('Mensagem que será enviada no corpo do E-mail. Use {{senha}} para Enviar a senha e {{email}}', 'redux_docs_generator'),

                'default' => '',
                'args' => array(
                    'teeny' => true,
                    'textarea_rows' => 10,
                    'media_buttons' => false,

                ),

                array(
                    'id' => 'text_use_woo',
                    'readonly' => true,
                    'type' => 'info',
                    'notice' => true,
                    'title' => esc_html__('Como Integrar o WooCommerce com o Hotmart', 'ninja_hot_conect'),
                    'desc' => esc_html__('Para Integrar o WooCommerce com o Hotmart, basta criar um produto no WooCommerce com o mesmo nome de produto que tem no Hotmart com isso vamos verificar se os dois nomes são iguais e faremos a integração', 'ninja_hot_conect'),
    
                ),


            ),
        ),
    ),

);

// Integração com WooCommerce
Redux::setSection($opt_name,

    array(
        'title' => esc_html__('WooCommerce', 'ninja_hot_conect'),
        'id' => 'config_woo',
        'desc' => esc_html__('Configurações de Integração com WooCommerce', 'ninja_hot_conect'),
        'icon' => 'el el-home',
        'fields' => array(
            array(
                'id' => 'habilitar_woo_integracao',
                'type' => 'checkbox',
                'title' => esc_html__('Habilitar Integração com WooCommerce', 'ninja_hot_conect'),
                'desc' => esc_html__('Ao Habilitar esta opção, vamos criar um pedido de compra no WooCommerce com os dados vindo do Hotmart', 'ninja_hot_conect'),

            ),
        ),
    ),

);
